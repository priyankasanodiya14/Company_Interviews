package com.dipdeveloper.ibm.q07_hibernate;

// Q7. What is the N+1 problem in Hibernate? How do you fix it?

import java.util.*;
import java.util.stream.Collectors;

// Entity simulation (without actual JPA/Hibernate runtime)
class Department {
    private final Long id;
    private final String name;
    private List<Employee> employees;

    public Department(Long id, String name) { this.id = id; this.name = name; }
    public Long getId() { return id; }
    public String getName() { return name; }
    public List<Employee> getEmployees() { return employees; }
    public void setEmployees(List<Employee> e) { this.employees = e; }
}

class Employee {
    private final Long id;
    private final String name;
    private final Long departmentId;

    public Employee(Long id, String name, Long departmentId) {
        this.id = id; this.name = name; this.departmentId = departmentId;
    }
    public Long getId() { return id; }
    public String getName() { return name; }
    public Long getDepartmentId() { return departmentId; }
}

// Fake DB with query counter
class FakeDatabase {
    static int queryCount = 0;

    static final List<Department> DEPTS = List.of(
        new Department(1L, "Engineering"),
        new Department(2L, "Finance"),
        new Department(3L, "HR")
    );

    static final List<Employee> EMPLOYEES = List.of(
        new Employee(1L, "Alice", 1L), new Employee(2L, "Bob", 1L),
        new Employee(3L, "Carol", 2L), new Employee(4L, "Dave", 3L)
    );

    static List<Department> findAllDepts() {
        queryCount++;
        System.out.println("  [DB Query #" + queryCount + "] SELECT * FROM department");
        return new ArrayList<>(DEPTS);
    }

    static List<Employee> findEmployeesByDept(Long deptId) {
        queryCount++;
        System.out.println("  [DB Query #" + queryCount + "] SELECT * FROM employee WHERE dept_id=" + deptId);
        return EMPLOYEES.stream().filter(e -> e.getDepartmentId().equals(deptId)).collect(Collectors.toList());
    }

    static List<Department> findAllDeptsWithEmployees() {
        queryCount++;
        System.out.println("  [DB Query #" + queryCount + "] SELECT d.*, e.* FROM department d JOIN employee e ON e.dept_id=d.id");
        List<Department> depts = new ArrayList<>(DEPTS);
        depts.forEach(d -> d.setEmployees(EMPLOYEES.stream()
            .filter(e -> e.getDepartmentId().equals(d.getId()))
            .collect(Collectors.toList())));
        return depts;
    }
}

public class Q07_HibernateNPlus1 {

    public static void main(String[] args) {
        System.out.println("=== N+1 Problem Demo ===");
        FakeDatabase.queryCount = 0;

        List<Department> depts = FakeDatabase.findAllDepts();           // 1 query
        for (Department d : depts) {
            List<Employee> emps = FakeDatabase.findEmployeesByDept(d.getId()); // N queries!
            d.setEmployees(emps);
        }
        System.out.println("Total queries for N+1: " + FakeDatabase.queryCount); // 1 + 3 = 4

        System.out.println("\n=== FIX 1: JOIN FETCH (single query) ===");
        FakeDatabase.queryCount = 0;
        List<Department> fixed = FakeDatabase.findAllDeptsWithEmployees(); // 1 query
        System.out.println("Total queries with JOIN FETCH: " + FakeDatabase.queryCount); // 1

        for (Department d : fixed) {
            System.out.println(d.getName() + " -> " + d.getEmployees().size() + " employees");
        }

        System.out.println("\n=== Spring Data JPA Annotations Reference ===");
        System.out.println("@OneToMany(fetch = FetchType.LAZY)  -> triggers N+1");
        System.out.println("@Query(\"SELECT d FROM Dept d JOIN FETCH d.employees\") -> single query");
        System.out.println("@EntityGraph(attributePaths={\"employees\"}) -> on repository method");
        System.out.println("@BatchSize(size = 10)               -> batch loading (reduces N+1 to N/10+1)");

        System.out.println("\n=== @EntityGraph equivalent ===");
        System.out.println("Hibernate generates: SELECT d.*, e.* FROM department d");
        System.out.println("                     LEFT JOIN FETCH employee e ON e.dept_id = d.id");
    }
}
