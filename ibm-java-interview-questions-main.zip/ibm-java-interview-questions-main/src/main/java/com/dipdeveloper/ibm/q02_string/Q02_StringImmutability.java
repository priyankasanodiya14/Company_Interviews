package com.dipdeveloper.ibm.q02_string;

// Q2. Why is String immutable in Java? What is the String Pool?

public class Q02_StringImmutability {

    public static void main(String[] args) {
        // String Pool - JVM caches literals
        String s1 = "IBM";
        String s2 = "IBM";
        System.out.println("Pool: s1 == s2 ? " + (s1 == s2));       // true - same reference

        // Heap object - new String() bypasses pool
        String s3 = new String("IBM");
        System.out.println("Heap: s1 == s3 ? " + (s1 == s3));       // false - different reference
        System.out.println("equals: s1.equals(s3) ? " + s1.equals(s3)); // true - same content

        // intern() - forces into pool
        String s4 = s3.intern();
        System.out.println("After intern: s1 == s4 ? " + (s1 == s4)); // true

        // Immutability demo - concat creates NEW string
        String original = "IBM";
        String modified = original.concat(" Java");
        System.out.println("Original unchanged: " + original); // IBM
        System.out.println("New string: " + modified);         // IBM Java

        // StringBuilder - mutable, NOT thread-safe, fast
        StringBuilder sb = new StringBuilder("IBM");
        sb.append(" Java").append(" Interview");
        System.out.println("StringBuilder: " + sb); // IBM Java Interview

        // StringBuffer - mutable, thread-safe (synchronized), slower
        StringBuffer sbuf = new StringBuffer("IBM");
        sbuf.append(" Java");
        System.out.println("StringBuffer: " + sbuf); // IBM Java

        // String.format - for complex patterns
        String formatted = String.format("Company: %s, Year: %d", "IBM", 2025);
        System.out.println(formatted);

        // Java 15+ Text Blocks
        String json = """
                {
                    "company": "IBM",
                    "role": "Java Developer"
                }
                """;
        System.out.println("Text Block:\n" + json);
    }
}
