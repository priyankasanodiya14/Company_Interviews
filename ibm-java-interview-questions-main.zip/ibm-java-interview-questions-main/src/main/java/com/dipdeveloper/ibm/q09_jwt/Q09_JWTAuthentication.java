package com.dipdeveloper.ibm.q09_jwt;

// Q9. How do you implement JWT-based authentication in Spring Boot?

import java.util.*;
import java.util.Base64;
import java.util.function.Function;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;

/**
 * JWT Structure: header.payload.signature
 * header  = Base64URL({ "alg": "HS256", "typ": "JWT" })
 * payload = Base64URL({ "sub": "alice", "exp": 1234567890, ... })
 * signature = HMACSHA256(header + "." + payload, secret)
 */
public class Q09_JWTAuthentication {

    private static final String SECRET = "IBMInterviewSecretKey256BitsLong!!";

    // Encode Base64URL
    static String base64Encode(String input) {
        return Base64.getUrlEncoder().withoutPadding()
                     .encodeToString(input.getBytes(StandardCharsets.UTF_8));
    }

    // Decode Base64URL
    static String base64Decode(String input) {
        return new String(Base64.getUrlDecoder().decode(input), StandardCharsets.UTF_8);
    }

    // Generate HMAC-SHA256 signature
    static String sign(String data, String secret) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(secret.getBytes(), "HmacSHA256"));
        return Base64.getUrlEncoder().withoutPadding()
                     .encodeToString(mac.doFinal(data.getBytes()));
    }

    // Generate JWT
    static String generateToken(String username, long expiryMs) throws Exception {
        String header = base64Encode("{\"alg\":\"HS256\",\"typ\":\"JWT\"}");

        long expiry = System.currentTimeMillis() + expiryMs;
        String payloadJson = String.format(
            "{\"sub\":\"%s\",\"iat\":%d,\"exp\":%d,\"role\":\"ROLE_USER\"}",
            username, System.currentTimeMillis() / 1000, expiry / 1000
        );
        String payload = base64Encode(payloadJson);

        String signature = sign(header + "." + payload, SECRET);
        return header + "." + payload + "." + signature;
    }

    // Validate and extract claims
    static Map<String, String> validateToken(String token) throws Exception {
        String[] parts = token.split("\\.");
        if (parts.length != 3) throw new IllegalArgumentException("Invalid token");

        // Verify signature
        String expectedSig = sign(parts[0] + "." + parts[1], SECRET);
        if (!expectedSig.equals(parts[2])) throw new SecurityException("Invalid signature!");

        // Parse payload
        String payload = base64Decode(parts[1]);
        System.out.println("Decoded payload: " + payload);

        // Extract simple fields (demo only - use proper JSON in production)
        Map<String, String> claims = new HashMap<>();
        for (String entry : payload.replaceAll("[{}\"\\s]", "").split(",")) {
            String[] kv = entry.split(":", 2);
            if (kv.length == 2) claims.put(kv[0], kv[1]);
        }

        // Check expiry
        long exp = Long.parseLong(claims.get("exp")) * 1000;
        if (System.currentTimeMillis() > exp) throw new SecurityException("Token expired!");

        return claims;
    }

    public static void main(String[] args) throws Exception {
        System.out.println("=== JWT Authentication Flow ===\n");

        System.out.println("1. User logs in with credentials");
        System.out.println("2. Server validates credentials");
        System.out.println("3. Server generates JWT and returns to client");
        System.out.println("4. Client sends JWT in every request: Authorization: Bearer <token>");
        System.out.println("5. Server validates JWT signature on each request\n");

        // Generate token
        String token = generateToken("alice", 3600_000); // 1 hour
        System.out.println("Generated JWT:\n" + token);
        System.out.println("\nJWT parts:");
        System.out.println("Header  : " + base64Decode(token.split("\\.")[0]));
        System.out.println("Payload : " + base64Decode(token.split("\\.")[1]));
        System.out.println("Signature: " + token.split("\\.")[2]);

        System.out.println("\n=== Validating token ===");
        Map<String, String> claims = validateToken(token);
        System.out.println("Subject: " + claims.get("sub"));
        System.out.println("Role: " + claims.get("role"));
        System.out.println("Token is VALID ✓");

        System.out.println("\n=== Tampered token test ===");
        String tampered = token.substring(0, token.length() - 5) + "XXXXX";
        try { validateToken(tampered); }
        catch (SecurityException e) { System.out.println("Caught: " + e.getMessage()); }

        System.out.println("\n=== Spring Boot Filter Chain Reference ===");
        System.out.println("JwtAuthFilter extends OncePerRequestFilter");
        System.out.println("  -> extract token from Authorization header");
        System.out.println("  -> validate with JwtService.isTokenValid()");
        System.out.println("  -> set SecurityContextHolder.getContext().setAuthentication()");
        System.out.println("SecurityConfig: .addFilterBefore(jwtFilter, UsernamePasswordAuthFilter)");
    }
}
