package com.dipdeveloper.ibm.q13_optional;

// Q13. How does Java 8 Optional work? When should you use it?

import java.util.Optional;
import java.util.List;
import java.util.Arrays;

public class Q13_OptionalBestPractices {

    record User(int id, String email, int age) {}

    static User findUser(int id) {
        if (id == 1) return new User(1, "alice@ibm.com", 30);
        return null; // returns null for unknown ids
    }

    public static void main(String[] args) {

        System.out.println("=== Old way - NullPointerException risk ===");
        // User user = findUser(99);
        // user.getEmail(); // NPE!

        System.out.println("=== Optional.ofNullable - safe null handling ===");
        String email = Optional.ofNullable(findUser(1))
                .map(User::email)
                .orElse("default@ibm.com");
        System.out.println("Email: " + email); // alice@ibm.com

        String missing = Optional.ofNullable(findUser(99))
                .map(User::email)
                .orElse("default@ibm.com");
        System.out.println("Missing user email: " + missing); // default@ibm.com

        System.out.println("\n=== Optional methods ===");
        Optional<String> opt = Optional.of("IBM Java");

        System.out.println("isPresent: " + opt.isPresent());         // true
        System.out.println("get: " + opt.get());                     // IBM Java
        System.out.println("orElse: " + opt.orElse("default"));      // IBM Java
        System.out.println("isEmpty: " + Optional.empty().isEmpty()); // true (Java 11+)

        System.out.println("\n=== Chaining with filter ===");
        Optional.ofNullable(findUser(1))
                .filter(u -> u.age() > 25)
                .map(User::email)
                .ifPresent(e -> System.out.println("Found senior user: " + e));

        System.out.println("\n=== orElseGet - lazy evaluation ===");
        String lazy = Optional.<String>empty()
                .orElseGet(() -> "Generated: " + System.currentTimeMillis());
        System.out.println("Lazy: " + lazy);

        System.out.println("\n=== orElseThrow ===");
        try {
            Optional.empty().orElseThrow(() -> new RuntimeException("User not found!"));
        } catch (RuntimeException e) {
            System.out.println("Caught: " + e.getMessage());
        }

        System.out.println("\n=== Stream of Optional ===");
        List<Optional<String>> opts = Arrays.asList(
                Optional.of("Alice"), Optional.empty(), Optional.of("Bob")
        );
        opts.stream()
                .filter(Optional::isPresent)
                .map(Optional::get)
                .forEach(System.out::println);
    }
}
