package com.dipdeveloper.ibm.q12_singleton;

// Q12. Implement Thread-safe Singleton. Explain all 3 approaches.

public class Q12_ThreadSafeSingleton {

    // ===== APPROACH 1: Synchronized getInstance (Simple but slow) =====
    static class SingletonV1 {
        private static SingletonV1 instance;
        private int value = 42;

        private SingletonV1() {
            System.out.println("SingletonV1 created");
        }

        // Synchronized on every call - unnecessary overhead after init
        public static synchronized SingletonV1 getInstance() {
            if (instance == null) {
                instance = new SingletonV1();
            }
            return instance;
        }
        public int getValue() { return value; }
    }

    // ===== APPROACH 2: Double-Checked Locking (Recommended) =====
    static class SingletonV2 {
        // volatile prevents instruction reordering - CRITICAL
        private static volatile SingletonV2 instance;
        private int value = 42;

        private SingletonV2() {
            System.out.println("SingletonV2 created");
        }

        public static SingletonV2 getInstance() {
            if (instance == null) {                    // 1st check (no sync - fast)
                synchronized (SingletonV2.class) {
                    if (instance == null) {            // 2nd check (with sync - safe)
                        instance = new SingletonV2();
                    }
                }
            }
            return instance;
        }
        public int getValue() { return value; }
    }

    // ===== APPROACH 3: Enum Singleton (BEST PRACTICE) =====
    // - JVM guarantees one instance
    // - Serialization safe (no deserialization creates new instance)
    // - Reflection attack safe (cannot instantiate via reflection)
    enum SingletonV3 {
        INSTANCE;

        private int value = 42;

        public void doSomething() {
            System.out.println("SingletonV3 Enum: value = " + value);
        }
        public int getValue() { return value; }
    }

    public static void main(String[] args) {
        System.out.println("=== Approach 1: Synchronized ===");
        SingletonV1 a = SingletonV1.getInstance();
        SingletonV1 b = SingletonV1.getInstance();
        System.out.println("Same instance? " + (a == b)); // true

        System.out.println("\n=== Approach 2: Double-Checked Locking ===");
        SingletonV2 c = SingletonV2.getInstance();
        SingletonV2 d = SingletonV2.getInstance();
        System.out.println("Same instance? " + (c == d)); // true
        System.out.println("volatile keyword prevents CPU instruction reordering");

        System.out.println("\n=== Approach 3: Enum (Best Practice) ===");
        SingletonV3.INSTANCE.doSomething();
        System.out.println("Same instance? " + (SingletonV3.INSTANCE == SingletonV3.INSTANCE));
        System.out.println("Enum singleton is safe against: reflection, serialization, cloning");
    }
}
