package com.dipdeveloper.ibm.q03_deadlock;

// Q3. Explain deadlock in Java. How do you prevent it?

import java.util.concurrent.locks.*;
import java.util.concurrent.TimeUnit;

public class Q03_DeadlockAndPrevention {

    static final Object LOCK_A = new Object();
    static final Object LOCK_B = new Object();
    static ReentrantLock lock1 = new ReentrantLock();
    static ReentrantLock lock2 = new ReentrantLock();

    // ❌ DEADLOCK: Thread1 holds A -> waits B | Thread2 holds B -> waits A
    static void deadlockScenario() {
        Thread t1 = new Thread(() -> {
            synchronized (LOCK_A) {
                System.out.println("T1 acquired LOCK_A");
                try { Thread.sleep(50); } catch (InterruptedException e) {}
                // T1 now waits for LOCK_B (held by T2)
                synchronized (LOCK_B) {
                    System.out.println("T1 acquired LOCK_B - UNREACHABLE");
                }
            }
        }, "Thread-1");

        Thread t2 = new Thread(() -> {
            synchronized (LOCK_B) {
                System.out.println("T2 acquired LOCK_B");
                try { Thread.sleep(50); } catch (InterruptedException e) {}
                // T2 now waits for LOCK_A (held by T1)
                synchronized (LOCK_A) {
                    System.out.println("T2 acquired LOCK_A - UNREACHABLE");
                }
            }
        }, "Thread-2");

        // t1.start(); t2.start(); // Commented to avoid actual deadlock in demo
        System.out.println("Deadlock scenario explained (not started to avoid freeze)");
    }

    // ✅ FIX 1: Consistent Lock Ordering - always acquire A before B
    static void preventWithOrdering() throws InterruptedException {
        Thread t1 = new Thread(() -> {
            synchronized (LOCK_A) {       // Always A first
                synchronized (LOCK_B) { System.out.println("T1 safe: got both locks"); }
            }
        });
        Thread t2 = new Thread(() -> {
            synchronized (LOCK_A) {       // Always A first
                synchronized (LOCK_B) { System.out.println("T2 safe: got both locks"); }
            }
        });
        t1.start(); t2.start();
        t1.join(); t2.join();
    }

    // ✅ FIX 2: tryLock with timeout - backs off if can't acquire
    static void preventWithTryLock() throws InterruptedException {
        Thread t1 = new Thread(() -> {
            try {
                boolean got1 = lock1.tryLock(100, TimeUnit.MILLISECONDS);
                boolean got2 = lock2.tryLock(100, TimeUnit.MILLISECONDS);
                if (got1 && got2) {
                    try {
                        System.out.println("T1: Both locks acquired via tryLock");
                    } finally {
                        lock1.unlock(); lock2.unlock();
                    }
                } else {
                    if (got1) lock1.unlock();
                    if (got2) lock2.unlock();
                    System.out.println("T1: Could not get both locks, backing off");
                }
            } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        });
        t1.start(); t1.join();
    }

    public static void main(String[] args) throws InterruptedException {
        System.out.println("=== Deadlock Scenario ===");
        deadlockScenario();

        System.out.println("\n=== Fix 1: Lock Ordering ===");
        preventWithOrdering();

        System.out.println("\n=== Fix 2: tryLock ===");
        preventWithTryLock();
    }
}
