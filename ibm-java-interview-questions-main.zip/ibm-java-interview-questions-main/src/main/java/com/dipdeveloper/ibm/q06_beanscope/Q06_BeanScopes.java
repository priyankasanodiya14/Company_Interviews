package com.dipdeveloper.ibm.q06_beanscope;

// Q6. What are Spring Bean Scopes? Singleton vs Prototype?
// This file shows the concepts. Spring context needed for actual @Scope behavior.

/**
 * SPRING BEAN SCOPES:
 *
 * @Scope("singleton")  - DEFAULT. One instance per ApplicationContext
 * @Scope("prototype")  - New instance every time getBean() is called
 * @Scope("request")    - One per HTTP request (web apps)
 * @Scope("session")    - One per HTTP session (web apps)
 * @Scope("application") - One per ServletContext
 *
 * THREAD SAFETY WARNING:
 * Singleton beans are NOT thread-safe if they hold mutable state!
 */

public class Q06_BeanScopes {

    // Simulates Singleton behavior
    static class SingletonCounter {
        private int count = 0;  // ⚠️ DANGEROUS: mutable state in singleton

        public void increment() { count++; }
        public int getCount() { return count; }
    }

    // Simulates Prototype behavior  
    static class PrototypeCounter {
        private int count = 0;  // SAFE: each caller gets their own instance

        public void increment() { count++; }
        public int getCount() { return count; }
    }

    // Thread-safe singleton using AtomicInteger
    static class ThreadSafeCounter {
        private final java.util.concurrent.atomic.AtomicInteger count =
                new java.util.concurrent.atomic.AtomicInteger(0);

        public void increment() { count.incrementAndGet(); }
        public int getCount() { return count.get(); }
    }

    public static void main(String[] args) throws InterruptedException {
        System.out.println("=== Singleton Scope (single shared instance) ===");
        SingletonCounter s = new SingletonCounter();
        s.increment(); s.increment(); s.increment();
        System.out.println("Count: " + s.getCount()); // 3

        System.out.println("\n=== Prototype Scope (new instance each time) ===");
        PrototypeCounter p1 = new PrototypeCounter();
        PrototypeCounter p2 = new PrototypeCounter();
        p1.increment(); p1.increment();
        p2.increment();
        System.out.println("p1 count: " + p1.getCount()); // 2
        System.out.println("p2 count: " + p2.getCount()); // 1
        System.out.println("Same instance? " + (p1 == p2)); // false

        System.out.println("\n=== Thread Safety Issue in Singleton ===");
        SingletonCounter shared = new SingletonCounter();
        Thread[] threads = new Thread[100];
        for (int i = 0; i < 100; i++) {
            threads[i] = new Thread(() -> shared.increment());
            threads[i].start();
        }
        for (Thread t : threads) t.join();
        System.out.println("Expected 100, Got: " + shared.getCount() + " (may be less due to race!)");

        System.out.println("\n=== Fix: ThreadSafe Singleton with AtomicInteger ===");
        ThreadSafeCounter safe = new ThreadSafeCounter();
        Thread[] safeThreads = new Thread[100];
        for (int i = 0; i < 100; i++) {
            safeThreads[i] = new Thread(() -> safe.increment());
            safeThreads[i].start();
        }
        for (Thread t : safeThreads) t.join();
        System.out.println("Expected 100, Got: " + safe.getCount() + " (always correct!)");

        System.out.println("\n=== Spring Config Reference ===");
        System.out.println("@Bean @Scope(\"singleton\")  -> shared, one per context");
        System.out.println("@Bean @Scope(\"prototype\")  -> new per getBean() call");
        System.out.println("@Bean @RequestScope         -> new per HTTP request");
        System.out.println("@Bean @SessionScope         -> new per HTTP session");
    }
}
