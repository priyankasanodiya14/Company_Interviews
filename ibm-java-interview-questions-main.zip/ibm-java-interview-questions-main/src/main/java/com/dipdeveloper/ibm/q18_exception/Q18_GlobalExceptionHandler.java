package com.dipdeveloper.ibm.q18_exception;

// Q18. How do you implement Global Exception Handling in Spring Boot?
// Spring annotations shown as comments - run with Spring Boot context.

import java.time.LocalDateTime;
import java.util.*;

// Custom Exception hierarchy
class ResourceNotFoundException extends RuntimeException {
    private final String resourceName;
    private final Object resourceId;

    public ResourceNotFoundException(String resourceName, Object resourceId) {
        super(resourceName + " not found with id: " + resourceId);
        this.resourceName = resourceName;
        this.resourceId = resourceId;
    }
    public String getResourceName() { return resourceName; }
    public Object getResourceId() { return resourceId; }
}

class ValidationException extends RuntimeException {
    private final Map<String, String> fieldErrors;

    public ValidationException(Map<String, String> errors) {
        super("Validation failed");
        this.fieldErrors = errors;
    }
    public Map<String, String> getFieldErrors() { return fieldErrors; }
}

// Error response DTO
record ErrorResponse(
    int status,
    String error,
    String message,
    String path,
    LocalDateTime timestamp,
    Map<String, String> fieldErrors
) {}

// @RestControllerAdvice equivalent simulation
public class Q18_GlobalExceptionHandler {

    // Simulates @ExceptionHandler(ResourceNotFoundException.class)
    static ErrorResponse handleNotFound(ResourceNotFoundException ex, String path) {
        System.out.println("[GlobalExceptionHandler] Handling ResourceNotFoundException");
        return new ErrorResponse(404, "Not Found", ex.getMessage(), path,
                LocalDateTime.now(), null);
    }

    // Simulates @ExceptionHandler(ValidationException.class)
    static ErrorResponse handleValidation(ValidationException ex, String path) {
        System.out.println("[GlobalExceptionHandler] Handling ValidationException");
        return new ErrorResponse(400, "Bad Request", ex.getMessage(), path,
                LocalDateTime.now(), ex.getFieldErrors());
    }

    // Simulates @ExceptionHandler(Exception.class) - catch-all
    static ErrorResponse handleAll(Exception ex, String path) {
        System.out.println("[GlobalExceptionHandler] Handling generic Exception");
        return new ErrorResponse(500, "Internal Server Error",
                "An unexpected error occurred", path, LocalDateTime.now(), null);
    }

    // Dispatch to correct handler (Spring does this automatically)
    static ErrorResponse dispatch(Exception ex, String path) {
        return switch (ex) {
            case ResourceNotFoundException e -> handleNotFound(e, path);
            case ValidationException e -> handleValidation(e, path);
            default -> handleAll(ex, path);
        };
    }

    public static void main(String[] args) {
        System.out.println("=== Global Exception Handling Demo ===\n");

        String[] paths = { "/api/users/999", "/api/users", "/api/orders" };
        Exception[] exceptions = {
            new ResourceNotFoundException("User", 999),
            new ValidationException(Map.of("email", "Invalid format", "name", "Name required")),
            new RuntimeException("Database connection lost")
        };

        for (int i = 0; i < exceptions.length; i++) {
            System.out.println("--- Request: " + paths[i] + " ---");
            ErrorResponse response = dispatch(exceptions[i], paths[i]);
            System.out.println("Status  : " + response.status());
            System.out.println("Error   : " + response.error());
            System.out.println("Message : " + response.message());
            if (response.fieldErrors() != null)
                System.out.println("Fields  : " + response.fieldErrors());
            System.out.println();
        }

        System.out.println("=== Spring Boot @RestControllerAdvice annotation reference ===");
        System.out.println("@RestControllerAdvice              -> applies globally");
        System.out.println("@ExceptionHandler(MyEx.class)      -> handles specific exception");
        System.out.println("ResponseEntity<ErrorResponse>      -> sets HTTP status + body");
        System.out.println("@ResponseStatus(HttpStatus.NOT_FOUND) -> shorthand status only");
    }
}
