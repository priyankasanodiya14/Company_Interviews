package com.dipdeveloper.ibm.q01_hashmap;

// Q1. How does HashMap work internally? What happens on hash collision?

import java.util.*;

public class Q01_HashMapInternals {

    public static void main(String[] args) {
        // Default capacity=16, load factor=0.75
        // Resize when size > 16 * 0.75 = 12 entries
        Map<String, Integer> map = new HashMap<>(16, 0.75f);

        map.put("Alice", 1);
        map.put("Bob", 2);
        map.put("Charlie", 3);

        // Hashcode determines the bucket index: (n-1) & hash
        System.out.println("Alice hashCode: " + "Alice".hashCode());
        System.out.println("Index in 16-bucket map: " + (15 & "Alice".hashCode()));

        // Java 8+: when a bucket has 8+ entries -> converts LinkedList to Red-Black Tree
        Map<Integer, String> collision = new HashMap<>();
        for (int i = 0; i < 20; i++) {
            collision.put(i * 16, "val" + i); // keys with same hash bucket
        }
        System.out.println("Size after collision inserts: " + collision.size());

        // getOrDefault - safe retrieval
        String val = collision.getOrDefault(999, "not found");
        System.out.println("Missing key result: " + val);

        // putIfAbsent - won't overwrite existing
        map.putIfAbsent("Alice", 99);
        System.out.println("Alice (unchanged): " + map.get("Alice")); // still 1

        // compute - update existing value
        map.compute("Alice", (k, v) -> v == null ? 1 : v + 10);
        System.out.println("Alice after compute: " + map.get("Alice")); // 11

        // merge - combine values
        map.merge("Bob", 5, Integer::sum);
        System.out.println("Bob after merge: " + map.get("Bob")); // 7
    }
}
