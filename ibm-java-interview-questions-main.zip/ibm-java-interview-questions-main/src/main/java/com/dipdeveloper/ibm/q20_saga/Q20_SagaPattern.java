package com.dipdeveloper.ibm.q20_saga;

// Q20. What is the Saga Pattern? Choreography vs Orchestration?

import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;

// ===== Choreography Saga - Event Driven =====

enum OrderStatus { PENDING, PAYMENT_PROCESSING, CONFIRMED, CANCELLED }
enum PaymentStatus { PENDING, SUCCESS, FAILED }

record Order(String id, double amount, OrderStatus status) {}
record PaymentResult(String orderId, boolean success, String reason) {}

class EventBus {
    private final Map<String, List<Consumer<Object>>> subscribers = new ConcurrentHashMap<>();

    @SuppressWarnings("unchecked")
    public <T> void subscribe(String topic, Consumer<T> handler) {
        subscribers.computeIfAbsent(topic, k -> new ArrayList<>())
                   .add((Consumer<Object>) handler);
    }

    @SuppressWarnings("unchecked")
    public void publish(String topic, Object event) {
        System.out.println("[EventBus] Publishing to: " + topic);
        subscribers.getOrDefault(topic, Collections.emptyList())
                   .forEach(h -> h.accept(event));
    }
}

class OrderService {
    private final EventBus bus;
    private final Map<String, Order> orders = new ConcurrentHashMap<>();

    public OrderService(EventBus bus) {
        this.bus = bus;
        // Listen for payment failure -> compensate
        bus.subscribe("payment.failed", (PaymentResult result) -> {
            orders.computeIfPresent(result.orderId(), (id, o) ->
                new Order(id, o.amount(), OrderStatus.CANCELLED));
            System.out.println("[OrderService] COMPENSATED: Order " + result.orderId() + " CANCELLED");
        });
        bus.subscribe("payment.success", (PaymentResult result) -> {
            orders.computeIfPresent(result.orderId(), (id, o) ->
                new Order(id, o.amount(), OrderStatus.CONFIRMED));
            System.out.println("[OrderService] Order " + result.orderId() + " CONFIRMED");
        });
    }

    public Order createOrder(String id, double amount) {
        Order order = new Order(id, amount, OrderStatus.PENDING);
        orders.put(id, order);
        System.out.println("[OrderService] Order created: " + id + " Rs." + amount);
        bus.publish("order.created", order);
        return order;
    }

    public Order getOrder(String id) { return orders.get(id); }
}

class PaymentService {
    private final EventBus bus;

    public PaymentService(EventBus bus) {
        this.bus = bus;
        bus.subscribe("order.created", (Order order) -> processPayment(order));
    }

    private void processPayment(Order order) {
        System.out.println("[PaymentService] Processing payment for: " + order.id());
        boolean success = order.amount() < 10000; // fail for large amounts
        PaymentResult result = new PaymentResult(order.id(), success,
                success ? "Approved" : "Insufficient funds");
        bus.publish(success ? "payment.success" : "payment.failed", result);
    }
}

class InventoryService {
    public InventoryService(EventBus bus) {
        bus.subscribe("payment.success", (PaymentResult result) ->
            System.out.println("[InventoryService] Reserved stock for order: " + result.orderId())
        );
    }
}

public class Q20_SagaPattern {

    public static void main(String[] args) {
        System.out.println("=== SAGA Pattern - Choreography Style ===\n");

        EventBus bus = new EventBus();
        OrderService orderSvc = new OrderService(bus);
        PaymentService paymentSvc = new PaymentService(bus);
        InventoryService inventorySvc = new InventoryService(bus);

        System.out.println("--- Scenario 1: Successful order (Rs. 5000) ---");
        orderSvc.createOrder("ORD-001", 5000);
        System.out.println("Final status: " + orderSvc.getOrder("ORD-001").status());

        System.out.println("\n--- Scenario 2: Failed payment (Rs. 15000) ---");
        orderSvc.createOrder("ORD-002", 15000);
        System.out.println("Final status: " + orderSvc.getOrder("ORD-002").status());

        System.out.println("\n=== Choreography vs Orchestration ===");
        System.out.println("Choreography: Services react to events (decoupled, harder to track)");
        System.out.println("Orchestration: Central Saga Orchestrator class directs each step");
        System.out.println("IBM preference: Orchestration for complex workflows (Axon Framework)");
    }
}
