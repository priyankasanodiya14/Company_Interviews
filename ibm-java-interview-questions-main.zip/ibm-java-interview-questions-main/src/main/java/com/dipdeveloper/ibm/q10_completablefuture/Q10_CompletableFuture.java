package com.dipdeveloper.ibm.q10_completablefuture;

// Q10. Explain CompletableFuture. How is it better than Future?

import java.util.concurrent.*;

public class Q10_CompletableFuture {

    public static void main(String[] args) throws Exception {

        System.out.println("=== 1. Basic async task ===");
        CompletableFuture<String> cf = CompletableFuture
                .supplyAsync(() -> fetchUser(1))        // runs on ForkJoinPool
                .thenApply(String::toUpperCase)          // transform result
                .thenApply(user -> "Hello, " + user);   // chain another transform

        System.out.println(cf.get()); // Hello, ALICE

        System.out.println("\n=== 2. Combine two futures (parallel microservice calls) ===");
        CompletableFuture<String> orderFuture =
                CompletableFuture.supplyAsync(Q10_CompletableFuture::fetchOrders);
        CompletableFuture<String> inventoryFuture =
                CompletableFuture.supplyAsync(Q10_CompletableFuture::fetchInventory);

        CompletableFuture<String> combined = orderFuture.thenCombine(
                inventoryFuture,
                (orders, inventory) -> orders + " | " + inventory
        );
        System.out.println("Combined: " + combined.get());

        System.out.println("\n=== 3. allOf - wait for ALL to complete ===");
        CompletableFuture<Void> allDone = CompletableFuture.allOf(orderFuture, inventoryFuture);
        allDone.thenRun(() -> System.out.println("All microservices responded!")).get();

        System.out.println("\n=== 4. Exception handling with exceptionally() ===");
        CompletableFuture<Object> safe = CompletableFuture
                .supplyAsync(() -> { throw new RuntimeException("DB connection failed"); })
                .exceptionally(ex -> "Fallback response: " + ex.getMessage());
        System.out.println(safe.get());

        System.out.println("\n=== 5. handle() - both success and failure ===");
        CompletableFuture<String> handled = CompletableFuture
                .supplyAsync(() -> fetchUser(2))
                .handle((result, ex) -> {
                    if (ex != null) return "Error: " + ex.getMessage();
                    return "Success: " + result;
                });
        System.out.println(handled.get());

        System.out.println("\n=== 6. thenCompose() - chain dependent futures ===");
        CompletableFuture<String> composed = CompletableFuture
                .supplyAsync(() -> fetchUser(1))
                .thenCompose(user -> CompletableFuture.supplyAsync(() -> fetchOrdersForUser(user)));
        System.out.println("Composed: " + composed.get());
    }

    static String fetchUser(int id) {
        try { Thread.sleep(50); } catch (InterruptedException e) {}
        return "alice";
    }

    static String fetchOrders() {
        try { Thread.sleep(100); } catch (InterruptedException e) {}
        return "Orders: [O1, O2, O3]";
    }

    static String fetchInventory() {
        try { Thread.sleep(80); } catch (InterruptedException e) {}
        return "Inventory: 50 units";
    }

    static String fetchOrdersForUser(String user) {
        return "Orders for " + user + ": [O1, O5]";
    }
}
