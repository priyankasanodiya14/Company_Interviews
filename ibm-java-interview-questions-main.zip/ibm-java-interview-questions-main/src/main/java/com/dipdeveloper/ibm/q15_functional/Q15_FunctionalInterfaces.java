package com.dipdeveloper.ibm.q15_functional;

// Q15. Explain Functional Interfaces. Write a custom one.

import java.util.function.*;
import java.util.*;

@FunctionalInterface
interface IBMValidator<T> {
    boolean validate(T value);

    // Default method - allowed in FunctionalInterface
    default IBMValidator<T> and(IBMValidator<T> other) {
        return t -> validate(t) && other.validate(t);
    }

    default IBMValidator<T> or(IBMValidator<T> other) {
        return t -> validate(t) || other.validate(t);
    }
}

public class Q15_FunctionalInterfaces {

    public static void main(String[] args) {

        System.out.println("=== Custom Functional Interface ===");
        IBMValidator<String> notEmpty = s -> !s.isEmpty();
        IBMValidator<String> notTooLong = s -> s.length() < 50;
        IBMValidator<String> alphaOnly = s -> s.matches("[a-zA-Z ]+");

        IBMValidator<String> combined = notEmpty.and(notTooLong).and(alphaOnly);

        System.out.println(combined.validate("IBM Java"));       // true
        System.out.println(combined.validate(""));               // false
        System.out.println(combined.validate("IBM123"));         // false (has digits)

        System.out.println("\n=== Built-in Functional Interfaces ===");

        // Predicate<T> - returns boolean
        Predicate<Integer> isPositive = n -> n > 0;
        Predicate<Integer> isEven = n -> n % 2 == 0;
        System.out.println("isPositive(5): " + isPositive.test(5));
        System.out.println("isPositive AND isEven (4): " + isPositive.and(isEven).test(4));

        // Function<T, R> - takes T, returns R
        Function<String, Integer> strlen = String::length;       // method reference
        Function<Integer, String> toStr = Object::toString;
        Function<String, String> lenStr = strlen.andThen(toStr); // compose
        System.out.println("lenStr('IBM'): " + lenStr.apply("IBM")); // "3"

        // Consumer<T> - takes T, returns nothing
        Consumer<String> printer = System.out::println;
        Consumer<String> upperPrinter = s -> System.out.println(s.toUpperCase());
        printer.andThen(upperPrinter).accept("ibm java");

        // Supplier<T> - takes nothing, returns T
        Supplier<List<String>> listFactory = ArrayList::new;
        List<String> list = listFactory.get();
        list.add("IBM"); list.add("Java");
        System.out.println("Supplier created list: " + list);

        // BiFunction<T, U, R>
        BiFunction<String, Integer, String> repeat = (s, n) -> s.repeat(n);
        System.out.println("repeat: " + repeat.apply("IBM ", 3));

        // UnaryOperator - Function where T == R
        UnaryOperator<String> shout = s -> s.toUpperCase() + "!";
        System.out.println("shout: " + shout.apply("ibm java"));
    }
}
