package com.dipdeveloper.ibm.q16_sealed;

// Q16. What are Sealed Classes in Java 17?

// Sealed class - only 3 permitted subclasses
sealed class Payment permits CreditCardPayment, UPIPayment, NetBankingPayment {
    protected final double amount;
    protected final String currency;

    public Payment(double amount, String currency) {
        this.amount = amount;
        this.currency = currency;
    }

    public abstract String process();
}

// Must be final, sealed, or non-sealed
final class CreditCardPayment extends Payment {
    private final String cardNumber;
    private final String cardHolder;

    public CreditCardPayment(double amount, String cardNumber, String cardHolder) {
        super(amount, "INR");
        this.cardNumber = cardNumber;
        this.cardHolder = cardHolder;
    }

    @Override
    public String process() {
        return String.format("CreditCard | %s | **** **** **** %s | Rs.%.2f",
                cardHolder, cardNumber.substring(cardNumber.length() - 4), amount);
    }
}

final class UPIPayment extends Payment {
    private final String upiId;

    public UPIPayment(double amount, String upiId) {
        super(amount, "INR");
        this.upiId = upiId;
    }

    @Override
    public String process() {
        return String.format("UPI | %s | Rs.%.2f", upiId, amount);
    }
}

non-sealed class NetBankingPayment extends Payment {
    // non-sealed = others CAN extend this
    protected final String bankCode;

    public NetBankingPayment(double amount, String bankCode) {
        super(amount, "INR");
        this.bankCode = bankCode;
    }

    @Override
    public String process() {
        return String.format("NetBanking | %s | Rs.%.2f", bankCode, amount);
    }
}

public class Q16_SealedClasses {

    // Java 21 - Pattern Matching with sealed (EXHAUSTIVE - no default needed!)
    static String describe(Payment p) {
        return switch (p) {
            case CreditCardPayment cc  -> "Card payment by " + cc.cardHolder;
            case UPIPayment upi        -> "UPI to " + upi.upiId;
            case NetBankingPayment nb  -> "Bank transfer via " + nb.bankCode;
            // Compiler verifies ALL subtypes covered - no default needed!
        };
    }

    public static void main(String[] args) {
        Payment[] payments = {
            new CreditCardPayment(5000, "4111111111111234", "Alice"),
            new UPIPayment(1500, "alice@okicici"),
            new NetBankingPayment(10000, "ICICI")
        };

        System.out.println("=== Processing Payments ===");
        for (Payment p : payments) {
            System.out.println(p.process());
        }

        System.out.println("\n=== Pattern Matching on Sealed Class ===");
        for (Payment p : payments) {
            System.out.println(describe(p));
        }

        System.out.println("\n=== Sealed class benefits ===");
        System.out.println("1. Exhaustive switch - compiler checks all cases");
        System.out.println("2. Restricted hierarchy - prevents unwanted extensions");
        System.out.println("3. Great for domain modeling (Result, Shape, Event)");
    }
}
