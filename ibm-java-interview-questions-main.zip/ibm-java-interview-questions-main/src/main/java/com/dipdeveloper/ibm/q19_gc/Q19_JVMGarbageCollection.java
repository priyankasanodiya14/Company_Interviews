package com.dipdeveloper.ibm.q19_gc;

// Q19. Explain JVM Garbage Collection. G1GC vs ZGC?

import java.lang.management.*;
import java.util.*;

public class Q19_JVMGarbageCollection {

    public static void main(String[] args) throws InterruptedException {

        System.out.println("=== JVM Heap Structure ===");
        System.out.println("Heap = Young Gen (Eden + S0 + S1) + Old Gen + Metaspace");
        System.out.println("New objects -> Eden -> Minor GC -> S0/S1 -> Old Gen -> Major GC");

        System.out.println("\n=== JVM Flags Reference ===");
        System.out.println("-XX:+UseG1GC              : G1 GC (default Java 9+)");
        System.out.println("-XX:+UseZGC               : ZGC (Java 15+, sub-ms pauses)");
        System.out.println("-XX:+UseShenandoahGC      : Shenandoah");
        System.out.println("-Xms512m -Xmx2g           : Initial and max heap");
        System.out.println("-XX:MaxGCPauseMillis=200  : Target pause time (G1GC)");
        System.out.println("-verbose:gc               : Print GC events");

        System.out.println("\n=== Current GC Info ===");
        for (GarbageCollectorMXBean gc : ManagementFactory.getGarbageCollectorMXBeans()) {
            System.out.println("GC Name      : " + gc.getName());
            System.out.println("Collections  : " + gc.getCollectionCount());
            System.out.println("Time (ms)    : " + gc.getCollectionTime());
            System.out.println("---");
        }

        System.out.println("\n=== Heap Memory Usage ===");
        MemoryMXBean memory = ManagementFactory.getMemoryMXBean();
        MemoryUsage heap = memory.getHeapMemoryUsage();
        System.out.printf("Used: %.1f MB%n", heap.getUsed() / 1_048_576.0);
        System.out.printf("Committed: %.1f MB%n", heap.getCommitted() / 1_048_576.0);
        System.out.printf("Max: %.1f MB%n", heap.getMax() / 1_048_576.0);

        System.out.println("\n=== Allocate and collect ===");
        List<byte[]> list = new ArrayList<>();
        for (int i = 0; i < 100; i++) {
            list.add(new byte[1024 * 100]); // 100KB each
        }
        System.out.printf("After alloc: %.1f MB used%n",
            memory.getHeapMemoryUsage().getUsed() / 1_048_576.0);

        list = null; // make eligible for GC
        System.gc();
        Thread.sleep(200);
        System.out.printf("After GC: %.1f MB used%n",
            memory.getHeapMemoryUsage().getUsed() / 1_048_576.0);

        System.out.println("\n=== GC Comparison ===");
        System.out.println("G1GC:       Balanced latency+throughput. Default Java 9+. Good for 6-32GB heaps");
        System.out.println("ZGC:        Sub-millisecond pauses. Java 15+. TB-scale heaps. IBM Cloud workloads");
        System.out.println("Shenandoah: Low-pause. Good for medium-large heaps. Red Hat contributed");
        System.out.println("Parallel:   Max throughput. Larger pauses. Good for batch jobs");
        System.out.println("\nTools: VisualVM, JConsole, GCViewer, Prometheus+Grafana");
    }
}
