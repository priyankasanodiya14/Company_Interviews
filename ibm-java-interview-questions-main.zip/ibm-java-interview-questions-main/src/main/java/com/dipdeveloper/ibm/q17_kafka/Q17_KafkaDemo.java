package com.dipdeveloper.ibm.q17_kafka;

// Q17. How do you integrate Apache Kafka with Spring Boot?

import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;

// Simulates Kafka Producer/Consumer without actual Kafka broker
// In production, use Spring Kafka with @KafkaListener and KafkaTemplate

record OrderEvent(String orderId, String status, double amount, long timestamp) {
    @Override public String toString() {
        return String.format("OrderEvent{orderId='%s', status='%s', amount=%.2f}", orderId, status, amount);
    }
}

// Simulates Kafka Topic (in-memory for demo)
class InMemoryTopic<T> {
    private final String name;
    private final LinkedBlockingQueue<T> queue = new LinkedBlockingQueue<>();
    private final List<Consumer<T>> consumers = new CopyOnWriteArrayList<>();

    public InMemoryTopic(String name) { this.name = name; }

    // Simulates KafkaTemplate.send()
    public void send(String key, T message) {
        System.out.printf("[Topic: %s] Producer sending key='%s': %s%n", name, key, message);
        queue.offer(message);
        consumers.forEach(c -> c.accept(message));
    }

    // Simulates @KafkaListener
    public void subscribe(Consumer<T> listener) { consumers.add(listener); }
}

// Simulates Spring Kafka Producer
class OrderProducer {
    private final InMemoryTopic<OrderEvent> topic;

    public OrderProducer(InMemoryTopic<OrderEvent> topic) { this.topic = topic; }

    public void publishOrder(OrderEvent event) {
        topic.send(event.orderId(), event);
    }
}

// Simulates Spring Kafka Consumer
class OrderConsumer {
    private final List<OrderEvent> processedEvents = new ArrayList<>();

    // Simulates @KafkaListener(topics="order-events", groupId="ibm-group")
    public void consume(OrderEvent event) {
        System.out.printf("[Consumer - ibm-group] Received: %s (partition=0, offset=%d)%n",
                event, processedEvents.size());
        processedEvents.add(event);
        processOrder(event);
    }

    private void processOrder(OrderEvent event) {
        switch (event.status()) {
            case "CREATED"    -> System.out.println("  -> Processing new order: " + event.orderId());
            case "CANCELLED"  -> System.out.println("  -> Rolling back order: " + event.orderId());
            case "SHIPPED"    -> System.out.println("  -> Updating inventory for: " + event.orderId());
            default           -> System.out.println("  -> Unknown status: " + event.status());
        }
    }

    public List<OrderEvent> getProcessedEvents() { return processedEvents; }
}

public class Q17_KafkaDemo {

    public static void main(String[] args) throws InterruptedException {
        System.out.println("=== Kafka Producer-Consumer Demo ===\n");

        // Setup
        InMemoryTopic<OrderEvent> orderTopic = new InMemoryTopic<>("order-events");
        OrderConsumer consumer1 = new OrderConsumer();
        OrderConsumer consumer2 = new OrderConsumer(); // Second consumer (different group)

        orderTopic.subscribe(consumer1::consume);
        // consumer2 not subscribed to same topic (simulates different consumer group)

        OrderProducer producer = new OrderProducer(orderTopic);

        System.out.println("--- Publishing 3 order events ---");
        producer.publishOrder(new OrderEvent("ORD-001", "CREATED", 5000.0, System.currentTimeMillis()));
        Thread.sleep(50);
        producer.publishOrder(new OrderEvent("ORD-002", "SHIPPED", 2500.0, System.currentTimeMillis()));
        Thread.sleep(50);
        producer.publishOrder(new OrderEvent("ORD-001", "CANCELLED", 5000.0, System.currentTimeMillis()));

        System.out.println("\n=== Processed " + consumer1.getProcessedEvents().size() + " events ===");

        System.out.println("\n=== Spring Boot Kafka Reference ===");
        System.out.println("Dependency: spring-kafka");
        System.out.println("Producer: KafkaTemplate<String, OrderEvent>.send(topic, key, event)");
        System.out.println("Consumer: @KafkaListener(topics=\"order-events\", groupId=\"ibm-group\")");
        System.out.println("Config:   spring.kafka.bootstrap-servers=localhost:9092");
        System.out.println("Consumer groups enable parallel processing across partitions");
        System.out.println("At-most-once vs At-least-once vs Exactly-once delivery semantics");
        System.out.println("\nKafka vs RabbitMQ:");
        System.out.println("Kafka: High throughput, event log, replay possible, ordered per partition");
        System.out.println("RabbitMQ: Complex routing, queue-based, message TTL, dead letter queues");
    }
}
