package com.dipdeveloper.ibm.q04_streams;

// Q4. Explain Java 8 Stream API. Difference between map() and flatMap()?

import java.util.*;
import java.util.stream.*;

public class Q04_StreamAPI {

    public static void main(String[] args) {
        List<String> names = Arrays.asList("alice", "bob", "charlie", "david", "alice");

        // map() - 1-to-1 transformation
        List<String> upper = names.stream()
                .map(String::toUpperCase)
                .collect(Collectors.toList());
        System.out.println("map (uppercase): " + upper);

        // filter + map + collect
        List<String> filtered = names.stream()
                .filter(n -> n.length() > 3)
                .map(n -> n.substring(0, 1).toUpperCase() + n.substring(1))
                .distinct()
                .sorted()
                .collect(Collectors.toList());
        System.out.println("filter+map+distinct+sorted: " + filtered);

        // flatMap() - 1-to-many (flattens nested collections)
        List<List<Integer>> nested = Arrays.asList(
                Arrays.asList(1, 2, 3),
                Arrays.asList(4, 5, 6),
                Arrays.asList(7, 8, 9)
        );
        List<Integer> flat = nested.stream()
                .flatMap(Collection::stream)
                .collect(Collectors.toList());
        System.out.println("flatMap result: " + flat);

        // reduce
        int sum = IntStream.rangeClosed(1, 10)
                .filter(n -> n % 2 == 0)
                .reduce(0, Integer::sum);
        System.out.println("Sum of even numbers 1-10: " + sum); // 30

        // groupingBy - IBM favourite
        Map<Integer, List<String>> byLength = names.stream()
                .collect(Collectors.groupingBy(String::length));
        System.out.println("Grouped by length: " + byLength);

        // counting per group
        Map<Integer, Long> countByLength = names.stream()
                .collect(Collectors.groupingBy(String::length, Collectors.counting()));
        System.out.println("Count by length: " + countByLength);

        // joining
        String joined = names.stream()
                .distinct()
                .collect(Collectors.joining(", ", "[", "]"));
        System.out.println("Joined: " + joined);

        // findFirst (lazy - stops after first match)
        Optional<String> first = names.stream()
                .filter(n -> n.startsWith("c"))
                .findFirst();
        first.ifPresent(n -> System.out.println("First 'c' name: " + n));

        // parallel stream
        long count = names.parallelStream()
                .filter(n -> n.length() > 3)
                .count();
        System.out.println("Names longer than 3 chars: " + count);
    }
}
