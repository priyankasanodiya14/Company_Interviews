package com.dipdeveloper.ibm.q05_autoconfig;

// Q5. How does Spring Boot Auto-Configuration work internally?
// Run this with Spring Boot context to see auto-config in action.
// Key annotations shown below (Spring Boot context needed for full run).

/**
 * AUTO-CONFIGURATION FLOW:
 *
 * @SpringBootApplication
 *  = @ComponentScan + @EnableAutoConfiguration + @Configuration
 *
 * @EnableAutoConfiguration triggers:
 *   -> Reads META-INF/spring/org.springframework.boot.autoconfigure.AutoConfiguration.imports
 *   -> Each config class evaluated with @Conditional* annotations
 *   -> Matching beans are created in ApplicationContext
 *
 * @ConditionalOnClass       - bean created only if class is on classpath
 * @ConditionalOnMissingBean - bean created only if no existing bean of that type
 * @ConditionalOnProperty    - bean created only if property is set
 */

// Simulate the auto-config mechanism without Spring context
import java.util.*;

public class Q05_SpringBootAutoConfig {

    // Simulates @ConditionalOnClass
    static boolean isClassPresent(String className) {
        try { Class.forName(className); return true; }
        catch (ClassNotFoundException e) { return false; }
    }

    // Simulates @ConditionalOnProperty
    static boolean isPropertySet(Map<String, String> props, String key, String value) {
        return value.equals(props.getOrDefault(key, value));
    }

    static class IBMNotificationService {
        public void send(String msg) {
            System.out.println("[IBMNotificationService] " + msg);
        }
    }

    // Simulates auto-configuration class
    static class IBMAutoConfiguration {
        private final Map<String, String> props;
        private final Map<String, Object> existingBeans;

        IBMAutoConfiguration(Map<String, String> props, Map<String, Object> existingBeans) {
            this.props = props; this.existingBeans = existingBeans;
        }

        Optional<IBMNotificationService> notificationServiceBean() {
            // @ConditionalOnClass
            if (!isClassPresent("com.dipdeveloper.ibm.q05_autoconfig.Q05_SpringBootAutoConfig$IBMNotificationService")) {
                System.out.println("SKIP: Class not on classpath");
                return Optional.empty();
            }
            // @ConditionalOnMissingBean
            if (existingBeans.containsKey("IBMNotificationService")) {
                System.out.println("SKIP: Bean already defined by user");
                return Optional.empty();
            }
            // @ConditionalOnProperty
            if (!isPropertySet(props, "ibm.notify.enabled", "true")) {
                System.out.println("SKIP: Property ibm.notify.enabled not true");
                return Optional.empty();
            }
            System.out.println("AUTO-CONFIGURED: IBMNotificationService bean created");
            return Optional.of(new IBMNotificationService());
        }
    }

    public static void main(String[] args) {
        System.out.println("=== Spring Boot Auto-Configuration Simulation ===\n");

        // Scenario 1: Normal auto-config
        Map<String, String> props = Map.of("ibm.notify.enabled", "true");
        Map<String, Object> beans = new HashMap<>();

        IBMAutoConfiguration config = new IBMAutoConfiguration(props, beans);
        config.notificationServiceBean()
              .ifPresent(svc -> svc.send("Hello IBM Interview!"));

        System.out.println("\n=== Scenario 2: User overrides bean (@ConditionalOnMissingBean) ===");
        beans.put("IBMNotificationService", "custom bean");
        new IBMAutoConfiguration(props, beans).notificationServiceBean()
            .ifPresentOrElse(
                svc -> svc.send("Won't reach"),
                () -> System.out.println("User's custom bean is used instead")
            );

        System.out.println("\n=== Real Spring Boot setup ===");
        System.out.println("File: META-INF/spring/AutoConfiguration.imports");
        System.out.println("Content: com.dipdeveloper.ibm.IBMAutoConfiguration");
        System.out.println("Spring reads this at startup and applies all conditions");
        System.out.println("\nDebug auto-config: --debug flag or logging.level.auto-configure=DEBUG");
    }
}
