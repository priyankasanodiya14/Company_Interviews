package com.dipdeveloper.ibm.q11_concurrenthashmap;

// Q11. How is ConcurrentHashMap different from HashMap and Hashtable?

import java.util.*;
import java.util.concurrent.*;

public class Q11_ConcurrentHashMap {

    public static void main(String[] args) throws InterruptedException {

        System.out.println("=== ConcurrentHashMap atomic operations ===");
        ConcurrentHashMap<String, Integer> chm = new ConcurrentHashMap<>();

        chm.put("a", 10);
        chm.putIfAbsent("a", 20);           // won't replace — already exists
        chm.putIfAbsent("b", 20);           // inserts b=20
        chm.computeIfAbsent("c", k -> k.length() * 10);  // c -> 10
        chm.merge("a", 5, Integer::sum);    // a = 10+5 = 15

        System.out.println(chm); // {a=15, b=20, c=10}

        System.out.println("\n=== Thread-safe concurrent increment ===");
        ConcurrentHashMap<String, Integer> counter = new ConcurrentHashMap<>();
        counter.put("count", 0);

        List<Thread> threads = new ArrayList<>();
        for (int i = 0; i < 100; i++) {
            Thread t = new Thread(() ->
                counter.merge("count", 1, Integer::sum)
            );
            threads.add(t);
            t.start();
        }
        for (Thread t : threads) t.join();
        System.out.println("Counter after 100 threads: " + counter.get("count")); // 100

        System.out.println("\n=== forEachEntry (parallel) ===");
        ConcurrentHashMap<String, Integer> scores = new ConcurrentHashMap<>();
        scores.put("Alice", 90); scores.put("Bob", 85); scores.put("Charlie", 92);

        scores.forEachEntry(1, entry ->
            System.out.println(entry.getKey() + " -> " + entry.getValue())
        );

        System.out.println("\n=== reduceValues ===");
        int total = scores.reduceValues(1, Integer::sum);
        System.out.println("Total score: " + total);

        System.out.println("\n=== Compare: HashMap not thread-safe ===");
        System.out.println("HashMap: Fast, no sync, NOT thread-safe");
        System.out.println("Hashtable: Synchronized every method, SLOW (legacy)");
        System.out.println("ConcurrentHashMap: Segment/bucket level sync, HIGH throughput");
        System.out.println("Reads in CHM are LOCK-FREE (Java 8+)");
    }
}
