package com.dipdeveloper.ibm.q08_circuitbreaker;

// Q8. What is Circuit Breaker? Implement with Resilience4j.

import java.util.concurrent.atomic.*;
import java.util.*;
import java.time.*;

enum CircuitState { CLOSED, OPEN, HALF_OPEN }

// Manual Circuit Breaker implementation (shows the concept)
// In production: use @CircuitBreaker from Resilience4j
class ManualCircuitBreaker {
    private CircuitState state = CircuitState.CLOSED;
    private final int failureThreshold;
    private final int successThreshold;
    private int failureCount = 0;
    private int successCount = 0;
    private Instant openedAt;
    private final Duration openDuration;

    public ManualCircuitBreaker(int failureThreshold, int successThreshold, Duration openDuration) {
        this.failureThreshold = failureThreshold;
        this.successThreshold = successThreshold;
        this.openDuration = openDuration;
    }

    public <T> T execute(java.util.concurrent.Callable<T> operation, java.util.concurrent.Callable<T> fallback) throws Exception {
        if (state == CircuitState.OPEN) {
            if (Duration.between(openedAt, Instant.now()).compareTo(openDuration) > 0) {
                System.out.println("[CB] Testing recovery -> HALF_OPEN");
                state = CircuitState.HALF_OPEN;
                successCount = 0;
            } else {
                System.out.println("[CB] Circuit OPEN -> using fallback");
                return fallback.call();
            }
        }

        try {
            T result = operation.call();
            onSuccess();
            return result;
        } catch (Exception e) {
            onFailure();
            System.out.println("[CB] Failure: " + e.getMessage() + " -> using fallback");
            return fallback.call();
        }
    }

    private void onSuccess() {
        failureCount = 0;
        if (state == CircuitState.HALF_OPEN) {
            successCount++;
            if (successCount >= successThreshold) {
                System.out.println("[CB] Recovery confirmed -> CLOSED");
                state = CircuitState.CLOSED;
            }
        }
    }

    private void onFailure() {
        failureCount++;
        if (failureCount >= failureThreshold) {
            System.out.println("[CB] Failure threshold reached -> OPEN");
            state = CircuitState.OPEN;
            openedAt = Instant.now();
        }
    }

    public CircuitState getState() { return state; }
}

public class Q08_CircuitBreaker {

    static int callCount = 0;

    static String callInventoryService() {
        callCount++;
        if (callCount <= 3 || callCount > 7) {
            return "Inventory: 50 units available";
        }
        throw new RuntimeException("Inventory service timeout!");
    }

    static String fallbackInventory() {
        return "CACHED: Inventory data (fallback)";
    }

    public static void main(String[] args) throws Exception {
        System.out.println("=== Circuit Breaker Pattern Demo ===\n");
        System.out.println("States: CLOSED (normal) -> OPEN (failing) -> HALF_OPEN (testing)");
        System.out.println();

        ManualCircuitBreaker cb = new ManualCircuitBreaker(3, 2, Duration.ofMillis(200));

        for (int i = 1; i <= 12; i++) {
            System.out.printf("Call #%2d [%s]: ", i, cb.getState());
            String result = cb.execute(
                Q08_CircuitBreaker::callInventoryService,
                Q08_CircuitBreaker::fallbackInventory
            );
            System.out.println(result);

            if (i == 6) {
                System.out.println("\n--- Waiting for circuit to transition to HALF_OPEN ---");
                Thread.sleep(250); // wait for open duration
                callCount = 8;     // simulate service recovered
            }
        }

        System.out.println("\n=== Resilience4j Spring Boot Reference ===");
        System.out.println("Dependency: spring-cloud-starter-circuitbreaker-resilience4j");
        System.out.println("@CircuitBreaker(name=\"inventoryService\", fallbackMethod=\"fallback\")");
        System.out.println("@Retry(name=\"inventoryService\", fallbackMethod=\"fallback\")");
        System.out.println("@Bulkhead(name=\"inventoryService\")  // limit concurrent calls");
        System.out.println("@RateLimiter(name=\"inventoryService\") // limit calls per second");
    }
}
