package com.dipdeveloper.ibm.q14_virtualthreads;

// Q14. What are Virtual Threads (Project Loom) in Java 21?

import java.util.concurrent.*;

public class Q14_VirtualThreads {

    public static void main(String[] args) throws Exception {

        System.out.println("=== Platform Thread (OS Thread) ===");
        Thread platformThread = new Thread(() ->
            System.out.println("Platform thread: " + Thread.currentThread()
                + " | isVirtual: " + Thread.currentThread().isVirtual())
        );
        platformThread.start();
        platformThread.join();

        System.out.println("\n=== Virtual Thread (JVM managed) ===");
        Thread virtualThread = Thread.ofVirtual().start(() ->
            System.out.println("Virtual thread: " + Thread.currentThread()
                + " | isVirtual: " + Thread.currentThread().isVirtual()) // true
        );
        virtualThread.join();

        System.out.println("\n=== Named Virtual Thread ===");
        Thread namedVT = Thread.ofVirtual().name("ibm-vthread").start(() ->
            System.out.println("Named virtual thread: " + Thread.currentThread().getName())
        );
        namedVT.join();

        System.out.println("\n=== 10,000 Virtual Threads - no problem! ===");
        long start = System.currentTimeMillis();

        try (var executor = Executors.newVirtualThreadPerTaskExecutor()) {
            for (int i = 0; i < 10_000; i++) {
                int taskId = i;
                executor.submit(() -> {
                    // Simulate I/O wait - platform threads would block OS threads
                    // Virtual threads park the VT and free the carrier thread
                    Thread.sleep(10);
                    if (taskId % 2000 == 0)
                        System.out.println("Task " + taskId + " done on " + Thread.currentThread());
                    return taskId;
                });
            }
        } // auto-shuts down and waits for all tasks

        long elapsed = System.currentTimeMillis() - start;
        System.out.println("10,000 virtual thread tasks in " + elapsed + "ms");

        System.out.println("\n=== Key differences ===");
        System.out.println("Platform Thread: OS thread, ~1-2MB stack, ~thousands max");
        System.out.println("Virtual Thread:  JVM managed, ~few KB, MILLIONS possible");
        System.out.println("Spring Boot 3.2+: spring.threads.virtual.enabled=true");
    }
}
