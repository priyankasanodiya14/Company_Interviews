# Q7 - Hibernate N+1 Problem

## Spring Data JPA Code (add to Spring Boot project)

```java
@Entity
public class Department {
    @Id @GeneratedValue
    private Long id;
    private String name;

    @OneToMany(mappedBy = "department", fetch = FetchType.LAZY)
    private List<Employee> employees;
}

@Repository
public interface DepartmentRepository extends JpaRepository<Department, Long> {
    
    // ❌ N+1: 1 + N queries
    List<Department> findAll();
    
    // ✅ Fix 1: JOIN FETCH
    @Query("SELECT d FROM Department d JOIN FETCH d.employees")
    List<Department> findAllWithEmployees();
    
    // ✅ Fix 2: EntityGraph
    @EntityGraph(attributePaths = {"employees"})
    List<Department> findAllByName(String name);
}
```
