# IBM Java Interview Questions - Dip Developer 🎬

## Project Overview

This project contains **20 complete Java code examples** for IBM Java Interview Questions
targeting **3-8 years experienced** developers.

## Structure

```
src/main/java/com/dipdeveloper/ibm/
├── q01_hashmap/         Q1.  HashMap internal working
├── q02_string/          Q2.  String immutability & String Pool
├── q03_deadlock/        Q3.  Deadlock detection and prevention
├── q04_streams/         Q4.  Java 8 Stream API (map vs flatMap)
├── q05_autoconfig/      Q5.  Spring Boot Auto-Configuration internals
├── q06_beanscope/       Q6.  Spring Bean Scopes (Singleton vs Prototype)
├── q07_hibernate/       Q7.  Hibernate N+1 problem & fixes
├── q08_circuitbreaker/  Q8.  Circuit Breaker pattern (Resilience4j)
├── q09_jwt/             Q9.  JWT Authentication implementation
├── q10_completablefuture/ Q10. CompletableFuture vs Future
├── q11_concurrenthashmap/ Q11. ConcurrentHashMap vs HashMap vs Hashtable
├── q12_singleton/       Q12. Thread-safe Singleton (3 approaches)
├── q13_optional/        Q13. Java 8 Optional best practices
├── q14_virtualthreads/  Q14. Virtual Threads (Java 21 - Project Loom)
├── q15_functional/      Q15. Functional Interfaces & custom @FunctionalInterface
├── q16_sealed/          Q16. Sealed Classes (Java 17)
├── q17_kafka/           Q17. Apache Kafka with Spring Boot
├── q18_exception/       Q18. Global Exception Handling (@RestControllerAdvice)
├── q19_gc/              Q19. JVM Garbage Collection (G1GC vs ZGC)
└── q20_saga/            Q20. Saga Pattern (Choreography vs Orchestration)
```

## How to Run

### Prerequisites
- Java 21+
- Maven 3.8+
- IntelliJ IDEA (recommended)

### Open in IntelliJ
1. File → Open → select `ibm_java_interview` folder
2. IntelliJ will detect pom.xml and import as Maven project
3. Navigate to any `Q0X_*.java` and click the Run button

### Questions that run standalone (no Spring context needed)
Q1, Q2, Q3, Q4, Q6, Q7, Q8, Q9, Q10, Q11, Q12, Q13, Q14, Q15, Q16, Q17, Q18, Q19, Q20

### Questions needing Spring Boot context
Q5 - Run with `@SpringBootApplication` main class (annotations shown as comments)

## Video Series
**Channel: Dip Developer** | IBM Java Interview Questions (3-8 Years Experience)
